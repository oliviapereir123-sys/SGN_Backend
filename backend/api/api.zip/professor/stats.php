<?php
/**
 * GET /professor/stats.php
 * Estatísticas do professor para o painel.
 *
 * CORRECÇÃO da fórmula de média:
 *   Prova do Professor (p1) × 40%
 *   Avaliação (p2)          × 30%
 *   Prova do Trimestre (exame) × 30%
 *
 * Critérios de aprovação IPM:
 *   0  – 6.9  → Reprovado
 *   7  – 9.9  → Recurso
 *   10 – 20   → Aprovado
 */
require_once __DIR__ . '/../../config/Headers.php';
require_once __DIR__ . '/../../config/Database.php';
require_once __DIR__ . '/../../config/Auth.php';

Auth::requireRole('professor');
$db   = new Database();
$conn = $db->connect();
$user = Auth::getUser();
$profId = intval($user['id']);

// Turmas do professor
$turmasR = $conn->prepare("
    SELECT DISTINCT
        t.id        AS id,
        t.nome      AS turma_nome,
        d.id        AS disciplina_id,
        d.nome      AS disciplina_nome,
        COUNT(DISTINCT a.id) AS total_alunos
    FROM professor_disciplinas pd
    JOIN turmas      t  ON pd.turma_id      = t.id
    JOIN disciplinas d  ON pd.disciplina_id = d.id
    LEFT JOIN alunos a  ON a.turma_id       = t.id
    WHERE pd.professor_id = ?
    GROUP BY t.id, d.id
");
$turmasR->bind_param("i", $profId);
$turmasR->execute();
$turmas = $turmasR->get_result()->fetch_all(MYSQLI_ASSOC);

$totalAlunos = 0;
foreach ($turmas as $t) $totalAlunos += intval($t['total_alunos']);

// Notas pendentes de validação
$pendR = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM notas
    WHERE professor_id = ? AND estado = 'Pendente'
");
$pendR->bind_param("i", $profId);
$pendR->execute();
$pendentes = intval($pendR->get_result()->fetch_assoc()['total']);

// Média geral — fórmula corrigida: PP×0.4 + AV×0.3 + PT×0.3
// (usando colunas p1/p2/exame se existirem, senão colunas legadas)
$mediaR = $conn->prepare("
    SELECT ROUND(AVG(
        COALESCE(p1, prova_professor) * 0.40 +
        COALESCE(p2, avaliacao)       * 0.30 +
        COALESCE(exame, prova_trimestre) * 0.30
    ), 1) AS media_geral
    FROM notas
    WHERE professor_id = ?
      AND estado = 'Aprovado'
      AND COALESCE(p1, prova_professor) IS NOT NULL
      AND COALESCE(p2, avaliacao) IS NOT NULL
      AND COALESCE(exame, prova_trimestre) IS NOT NULL
");
$mediaR->bind_param("i", $profId);
$mediaR->execute();
$mediaGeral = floatval($mediaR->get_result()->fetch_assoc()['media_geral'] ?? 0);

// Evolução por trimestre
$evolR = $conn->prepare("
    SELECT tr.nome AS trimestre,
           ROUND(AVG(
               COALESCE(n.p1, n.prova_professor) * 0.40 +
               COALESCE(n.p2, n.avaliacao)       * 0.30 +
               COALESCE(n.exame, n.prova_trimestre) * 0.30
           ), 1) AS media
    FROM notas n
    JOIN trimestres tr ON n.trimestre_id = tr.id
    WHERE n.professor_id = ? AND n.estado = 'Aprovado'
      AND COALESCE(n.p1, n.prova_professor) IS NOT NULL
      AND COALESCE(n.p2, n.avaliacao)       IS NOT NULL
      AND COALESCE(n.exame, n.prova_trimestre) IS NOT NULL
    GROUP BY tr.id, tr.nome
    ORDER BY tr.id
");
$evolR->bind_param("i", $profId);
$evolR->execute();
$evolucao = $evolR->get_result()->fetch_all(MYSQLI_ASSOC);

// Formatar médias como float
foreach ($evolucao as &$e) {
    $e['media'] = floatval($e['media']);
}

echo json_encode([
    'success'      => true,
    'total_alunos' => $totalAlunos,
    'total_turmas' => count($turmas),
    'pendentes'    => $pendentes,
    'media_geral'  => $mediaGeral,
    'turmas'       => $turmas,
    'evolucao'     => $evolucao,
]);
$db->closeConnection();